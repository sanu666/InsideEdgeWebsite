package com.groupfive.InsideEdge.InsideEdge;

import java.io.IOException;
import java.util.Iterator;

import org.json.JSONException;

import com.groupfive.InsideEdge.POJO.NewsPOJO;

public class testclass {

	public static void main(String[] args) throws IOException, JSONException {
		JsonGetNews getnews=new JsonGetNews();
		Iterator<NewsPOJO> itr=getnews.newsreturn().iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	}

}
