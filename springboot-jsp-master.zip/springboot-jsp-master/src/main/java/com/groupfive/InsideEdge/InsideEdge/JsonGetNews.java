package com.groupfive.InsideEdge.InsideEdge;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.groupfive.InsideEdge.POJO.NewsPOJO;



public class JsonGetNews {

  private static String readAll(Reader rd) throws IOException {
    StringBuilder sb = new StringBuilder();
    int cp;
    while ((cp = rd.read()) != -1) {
      sb.append((char) cp);
    }
    return sb.toString();
  }

  public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
    InputStream is = new URL(url).openStream();
    try {
      BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
      String jsonText = readAll(rd);
      JSONObject json = new JSONObject(jsonText);
      return json;
    } finally {
      is.close();
    }
  }

  public List<NewsPOJO> newsreturn() throws IOException, JSONException {
	  List<NewsPOJO> exceptionlist=new ArrayList<>();
	 try{
    //JSONObject json1 = readJsonFromUrl("https://powerful-tor-13817.herokuapp.com/live");
    JSONObject json2 = readJsonFromUrl("https://powerful-tor-13817.herokuapp.com/news");
    List<NewsPOJO> newslist=new ArrayList<>();
    
 


       
      JSONArray jsonarray1=json2.getJSONArray("Latest News");
 
      
      for (int index = 0, total = 5; index < total; index++) {
          final JSONObject jsonObject = jsonarray1.getJSONObject(index);
         
  
         NewsPOJO news=new NewsPOJO(jsonObject.getString("Title"));
         newslist.add(news);
      }
      return newslist;
	  }
      catch(Exception e)
      {
    	  NewsPOJO n=new NewsPOJO("SERVER TIMEOUT!!!");
    	  exceptionlist.add(n);
    	  return exceptionlist;
      }
          
  }
  
}