package com.groupfive.InsideEdge.POJO;

public class NewsPOJO {
	String title;

	public NewsPOJO(String title) {
		//super();
		this.title = title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		return title;
	}
	
	

}
